class Admin::PostsController < Admin::MasterController
end