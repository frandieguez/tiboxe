class Admin::TypusUsersController < Admin::MasterController
end