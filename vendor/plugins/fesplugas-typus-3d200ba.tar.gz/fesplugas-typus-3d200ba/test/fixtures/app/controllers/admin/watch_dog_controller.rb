class Admin::WatchDogController < TypusController

  def index
  end

end