class Admin::StatusController < TypusController

  def index
  end

end