class Admin::CommentsController < Admin::MasterController
end