class Admin::PagesController < Admin::MasterController
end