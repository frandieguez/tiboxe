class Admin::AssetsController < Admin::MasterController
end