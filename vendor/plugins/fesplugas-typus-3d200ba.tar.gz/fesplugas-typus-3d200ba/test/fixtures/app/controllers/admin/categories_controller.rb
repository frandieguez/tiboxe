class Admin::CategoriesController < Admin::MasterController
end