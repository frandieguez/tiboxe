require 'typus'

Typus.boot!