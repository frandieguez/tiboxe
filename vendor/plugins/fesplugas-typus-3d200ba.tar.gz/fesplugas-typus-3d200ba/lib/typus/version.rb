class Typus
  Version = '0.9.38'
end