class TypusUser < ActiveRecord::Base

  enable_as_typus_user

end